﻿using UnityEngine;

[ExecuteAlways]
public class LightingManager : MonoBehaviour
{
    public static LightingManager instance;
    //Scene References
    [SerializeField] private Light DirectionalLight;
   
    public float daySpeed = .1f;
    public float nightSpeed = .2f;
    //Variables
    [SerializeField, Range(0, 24)] private float TimeOfDay;

    private void Awake()
    {
        instance = this;
    }

    private void Update()
    {
        

        if (Application.isPlaying)
        {
           
            if(isDay())
            TimeOfDay += Time.deltaTime*daySpeed;
            else
            TimeOfDay += Time.deltaTime * nightSpeed;

            TimeOfDay %= 24; 
            UpdateLighting(TimeOfDay / 24f);
        }
        else
        {
            UpdateLighting(TimeOfDay / 24f);
        }
    }
    public bool isDay()
    {
        return (TimeOfDay >= 6&& TimeOfDay <= 17);
    }

    private void UpdateLighting(float timePercent)
    {
        
        if (DirectionalLight != null)
        {

            if (!isDay())
            {
                DirectionalLight.intensity = .2f;
            }
            else
            {
                DirectionalLight.intensity = 1;
            }
            DirectionalLight.transform.localRotation = Quaternion.Euler(new Vector3((timePercent * 360f) - 90f, 170f, 0));
        }

    }

   
    private void OnValidate()
    {
        if (DirectionalLight != null)
            return;

        
        if (RenderSettings.sun != null)
        {
            DirectionalLight = RenderSettings.sun;
        }
       
        else
        {
            Light[] lights = GameObject.FindObjectsOfType<Light>();
            foreach (Light light in lights)
            {
                if (light.type == LightType.Directional)
                {
                    DirectionalLight = light;
                    return;
                }
            }
        }
    }
}