﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fruit : MonoBehaviour
{
    public float maxFresh = 100f;
    public float growthSpeed;
    public Vector3 maxSize;
    public float decaySpeed = 1.0f;
    float currentFreshness;
    bool decaying = false;
    public float random = .75f;
    public GameObject eatenParticle;
    public float healthRestorefactor;
    public float deathUpForce = 10;
    // Start is called before the first frame update
    void Start()
    {
        maxSize *= Random.Range(random, 1f / random);
        currentFreshness = maxFresh;
        transform.localScale = Vector2.zero;
        LeanTween.scale(gameObject, maxSize, growthSpeed).setOnComplete(startDecay);
    }

    // Update is called once per frame
    void Update()
    {
        if (decaying)
        {
            currentFreshness -= decaySpeed * Time.deltaTime;
            float ratio = Mathf.Max((currentFreshness / maxFresh) , 0);
            //transform.localScale = maxSize * ratio;
            if (currentFreshness < 25)
            {
                //die
                GetComponent<Rigidbody>().isKinematic = false;
                GetComponent<Rigidbody>().useGravity = true;
                decaying = false;
                //GetComponent<Rigidbody>().AddForce(transform.up * deathUpForce,ForceMode.Impulse);
                Destroy(gameObject,5);

            }
        }
        
    }
    public void harvest()
    {
        
        Instantiate(eatenParticle, transform.position, Quaternion.identity);
        Destroy(gameObject);
        
    }
    
    public float getFreshRatio()
    {
        return Mathf.Max((currentFreshness / maxFresh), 0);
    }
    void startDecay()
    {
        decaying = true;
    }
    float getFreshness()
    {
        return currentFreshness;
    }
}
