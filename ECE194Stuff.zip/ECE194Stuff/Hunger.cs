﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Gamekit3D.Message;
using UnityEngine.Serialization;

namespace Gamekit3D
{
    public class Hunger : MonoBehaviour
    {
        public Damageable damage;
        public HealthUI hUI;
        public float hungerRate = .01f;//gain this much hunger every second at 1 hunger you lose a life and hunger resets
        [SerializeField]
        public Damageable.DamageMessage hungerMessage;
        

        float hungerAmt = 0f;
        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
            hungerAmt += hungerRate * Time.deltaTime;
            if(hungerAmt >= 1.0f)
            {
                hungerAmt = 0;
                damage.ApplyDamage(hungerMessage);
                hUI.ChangeHitPointUI(damage);
            }
        }
    }
}
