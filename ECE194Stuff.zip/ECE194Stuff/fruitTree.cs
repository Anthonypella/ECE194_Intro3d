﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fruitTree : MonoBehaviour
{
    public GameObject fruit;
    public Transform[] fruitSpawnPoints;
    public float spawnSpeed;//change to spawns per day
    private bool[] growingAtIndex;
    public float growthHeight = .5f;
    public int spawnOrientation = 1;
    float timer = 0;
    bool isGrowing = true;
    float fruitLife;
    float fruitGrowthSpeed;
    LightingManager day;
    // Start is called before the first frame updatebo
    void Start()
    {
        day = LightingManager.instance;
        fruitLife = fruit.GetComponent<fruit>().maxFresh / fruit.GetComponent<fruit>().decaySpeed;
        fruitGrowthSpeed = fruit.GetComponent<fruit>().growthSpeed;
        growingAtIndex = new bool[fruitSpawnPoints.Length];
        for (int i = 0; i < growingAtIndex.Length; i++)
        {
            growingAtIndex[i] = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (isGrowing && day.isDay())
        {
            timer -= Time.deltaTime;
            if(timer < 0)
            {
                timer = spawnSpeed;
                bool samePos = true;
                int i = 0;
                while (samePos && i < growingAtIndex.Length)
                {
                    int r = Random.Range(0, fruitSpawnPoints.Length);
                    if(growingAtIndex[r] == false)
                    {
                       GameObject a = Instantiate(fruit, fruitSpawnPoints[r].position , Quaternion.identity);
                        a.transform.transform.forward =spawnOrientation* fruitSpawnPoints[r].up;
                       
                        LeanTween.move(a, fruitSpawnPoints[r].position + fruitSpawnPoints[r].up * growthHeight, fruitGrowthSpeed);
                        growingAtIndex[r] = true;
                        samePos = false;
                        
                        StartCoroutine(fruitTimer(r));
                    }
                    else
                    {
                        i++;
                    }
                    
                }
                



            }
        }

        
    }
   
    
    IEnumerator fruitTimer(int i)
    {
        yield return new WaitForSeconds(fruitLife);
        growingAtIndex[i] = false;
    }
}
